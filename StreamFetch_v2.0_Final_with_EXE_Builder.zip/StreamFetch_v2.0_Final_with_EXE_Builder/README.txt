
StreamFetch v1.8 – YouTube Downloader Tool

FEATURES:
- Download single videos, playlists, or multiple links at once
- Choose output format: MP4, MP3, WAV, M4A, WEBM
- Custom filename and download folder
- Automatically installs yt_dlp and FFmpeg (on Windows)
- Places a shortcut on your Desktop
- Automatically checks and updates yt_dlp on each launch

USAGE:
1. Run 'install.bat' to build and place the app
2. Double-click 'StreamFetch.exe' on your Desktop
3. Paste YouTube links (1 per line), choose format, and download

TO UNINSTALL:
- Run 'uninstall.bat' to remove from Desktop

DONATIONS:
Support development: https://www.buymeacoffee.com/buggy666


AUTO-UPDATER:
StreamFetch v2.0 automatically updates yt-dlp every time it is launched.
This ensures compatibility with the latest YouTube changes.
