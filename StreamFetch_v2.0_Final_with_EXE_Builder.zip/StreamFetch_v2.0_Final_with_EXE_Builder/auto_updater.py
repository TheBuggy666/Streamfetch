
# Auto updater for yt_dlp
import subprocess
import sys

def update_yt_dlp():
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "yt-dlp"], check=True)
        print("✅ yt-dlp has been updated.")
    except Exception as e:
        print(f"⚠️ Update failed: {e}")

if __name__ == "__main__":
    update_yt_dlp()
