
import os
import subprocess
import sys
import tkinter as tk
import webbrowser
from tkinter import filedialog, messagebox, ttk
import zipfile
import urllib.request
import platform

# yt_dlp auto-install
try:
    from yt_dlp import YoutubeDL
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "yt-dlp"])
    from yt_dlp import YoutubeDL

# FFmpeg pad en check
FFMPEG_DIR = os.path.join(os.getcwd(), "bin")
FFMPEG_EXE = os.path.join(FFMPEG_DIR, "ffmpeg.exe")

def ffmpeg_installed():
    try:
        subprocess.run([FFMPEG_EXE if os.path.exists(FFMPEG_EXE) else "ffmpeg", "-version"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False

def download_ffmpeg():
    if platform.system() != "Windows":
        return False
    try:
        os.makedirs(FFMPEG_DIR, exist_ok=True)
        url = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
        zip_path = os.path.join(FFMPEG_DIR, "ffmpeg.zip")
        urllib.request.urlretrieve(url, zip_path)

        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(FFMPEG_DIR)

        for root, dirs, files in os.walk(FFMPEG_DIR):
            if "ffmpeg.exe" in files:
                src = os.path.join(root, "ffmpeg.exe")
                os.replace(src, FFMPEG_EXE)
                break
        os.remove(zip_path)
        return os.path.exists(FFMPEG_EXE)
    except Exception as e:
        messagebox.showerror("FFmpeg download mislukt", str(e))
        return False

def download():
    if not ffmpeg_installed():
        proceed = messagebox.askyesno("FFmpeg ontbreekt", "FFmpeg is vereist. Wil je het nu automatisch downloaden?")
        if proceed:
            if not download_ffmpeg():
                return
        else:
            return

    urls = url_text.get("1.0", tk.END).strip().splitlines()
    filename = filename_entry.get().strip()
    download_path = path_entry.get().strip()
    selected_format = format_var.get()

    if not urls:
        messagebox.showerror("Fout", "Voer ten minste één geldige YouTube-link in.")
        return

    if not filename:
        messagebox.showerror("Fout", "Voer een bestandsnaam in.")
        return

    if not download_path:
        download_path = os.getcwd()

    format_map = {
        "Video (MP4)": ("bestvideo+bestaudio/best", "mp4", "FFmpegVideoConvertor", "mp4"),
        "Audio (MP3)": ("bestaudio", "mp3", "FFmpegExtractAudio", "mp3"),
        "Audio (WAV)": ("bestaudio", "wav", "FFmpegExtractAudio", "wav"),
        "Audio (M4A)": ("bestaudio", "m4a", "FFmpegExtractAudio", "m4a"),
        "Audio (WEBM)": ("bestaudio", "webm", None, None)
    }

    fmt, ext, pp_key, pp_format = format_map[selected_format]

    ydl_opts = {
        'format': fmt,
        'outtmpl': os.path.join(download_path, f"{filename}_%(title)s.%(ext)s"),
        'ffmpeg_location': FFMPEG_DIR if os.path.exists(FFMPEG_EXE) else None,
        'noplaylist': False  # laat playlist-downloads toe
    }

    if pp_key:
        ydl_opts['postprocessors'] = [{
            'key': pp_key,
            'preferredcodec': pp_format,
            'preferredquality': '192'
        }] if 'Audio' in selected_format else [{
            'key': pp_key,
            'preferedformat': pp_format
        }]

    try:
        with YoutubeDL(ydl_opts) as ydl:
            for url in urls:
                if url.strip():
                    ydl.download([url.strip()])
        status_label.config(text="✅ Alle downloads voltooid.")
    except Exception as e:
        messagebox.showerror("Fout", f"Download mislukt: {e}")

def browse_folder():
    folder_selected = filedialog.askdirectory()
    if folder_selected:
        path_entry.delete(0, tk.END)
        path_entry.insert(0, folder_selected)

# GUI

# Auto-update yt_dlp on startup
try:
    subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "yt-dlp"], check=True)
except Exception as e:
    print(f"Updater warning: {e}")

root = tk.Tk()
root.title("StreamFetch – YouTube Downloader")

try:
    root.iconbitmap("streamfetch.ico")
except Exception:
    pass

root.geometry("560x450")
tk.Label(root, text="📺 StreamFetch – Download meerdere links of afspeellijsten", font=("Helvetica", 14, "bold")).pack(pady=10)

tk.Label(root, text="Plak hier één of meerdere YouTube-links (1 per regel):").pack(anchor="w", padx=10)
url_text = tk.Text(root, width=70, height=5)
url_text.pack(padx=10)

tk.Label(root, text="Bestandsnaam-basis (wordt aangevuld met videotitel):").pack(anchor="w", padx=10, pady=(10, 0))
filename_entry = tk.Entry(root, width=45)
filename_entry.pack(padx=10)

tk.Label(root, text="Downloadmap:").pack(anchor="w", padx=10, pady=(10, 0))
path_frame = tk.Frame(root)
path_entry = tk.Entry(path_frame, width=40)
path_entry.pack(side="left", padx=(0, 5))
tk.Button(path_frame, text="Bladeren", command=browse_folder).pack(side="left")
path_frame.pack(padx=10)

tk.Label(root, text="Kies formaat:").pack(anchor="w", padx=10, pady=(10, 0))
format_var = tk.StringVar(value="Video (MP4)")
formats = ["Video (MP4)", "Audio (MP3)", "Audio (WAV)", "Audio (M4A)", "Audio (WEBM)"]
format_dropdown = ttk.Combobox(root, textvariable=format_var, values=formats, state="readonly", width=30)
format_dropdown.pack(padx=10)

tk.Button(root, text="Downloaden", command=download).pack(pady=15)
status_label = tk.Label(root, text="", fg="green")
status_label.pack()


# Branding + donatie
tk.Label(root, text="Brought to you by Buggy_666", font=("Arial", 8, "italic")).pack(pady=(5, 0))
tk.Button(root, text="☕ Donate", command=lambda: webbrowser.open('https://www.buymeacoffee.com/Buggy_666666')).pack(pady=(0, 10))


tk.Label(root, text="StreamFetch v2.0", font=("Arial", 8)).pack(pady=(4, 0))
tk.Button(root, text="📄 View README", command=lambda: webbrowser.open('README.txt')).pack(pady=(0, 4))

root.mainloop()
